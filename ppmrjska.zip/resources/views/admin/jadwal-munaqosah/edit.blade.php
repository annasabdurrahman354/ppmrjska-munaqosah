@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    {{ trans('global.edit') }}
                    {{ trans('cruds.jadwalMunaqosah.title_singular') }}:
                    {{ trans('cruds.jadwalMunaqosah.fields.id') }}
                    {{ $jadwalMunaqosah->id }}
                </h6>
            </div>
        </div>

        <div class="card-body">
            @livewire('admin.jadwal-munaqosah.edit', [$jadwalMunaqosah])
        </div>
    </div>
</div>
@endsection