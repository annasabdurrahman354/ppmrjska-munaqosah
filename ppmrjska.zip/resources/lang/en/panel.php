<?php

return [
    'site_title' => 'PPM Roudlotul Jannah',
];
